
const statusEl = document.getElementById("status");
const resultsEl = document.getElementById("results");

async function loadWeather(params) {
  try {
    statusEl.textContent = "Loading...";
    resultsEl.classList.add("hidden");
    const qs = new URLSearchParams(params);
    const res = await fetch(`/api/weather?${qs.toString()}`);
    const data = await res.json();
    if (!res.ok) {
      statusEl.textContent = data.error || "Failed to fetch weather.";
      return;
    }

    // Current
    document.getElementById("locName").textContent = data.location_name;
    document.getElementById("curTemp").textContent = data.current.temp.toFixed(1);
    document.getElementById("curFeels").textContent = data.current.feels_like.toFixed(1);
    document.getElementById("curDesc").textContent = data.current.description;
    document.getElementById("curHum").textContent = data.current.humidity;
    document.getElementById("curPress").textContent = data.current.pressure;
    const windUnit = data.units === "imperial" ? "mph" : "m/s";
    document.getElementById("curWind").textContent = `${data.current.wind_speed} ${windUnit}`;
    document.getElementById("curIcon").src = `https://openweathermap.org/img/wn/${data.current.icon}@2x.png`;

    // Forecast
    const grid = document.getElementById("forecastGrid");
    grid.innerHTML = "";
    for (const d of data.forecast) {
      const date = new Date(d.date);
      const dayName = date.toLocaleDateString(undefined, { weekday: "short", month: "short", day: "numeric" });
      const el = document.createElement("div");
      el.className = "day";
      el.innerHTML = `
        <div>${dayName}</div>
        <img src="https://openweathermap.org/img/wn/${d.icon}@2x.png" alt="icon" />
        <div>${d.description}</div>
        <div class="hi-lo">H: ${d.temp_max}°, L: ${d.temp_min}°</div>
      `;
      grid.appendChild(el);
    }

    resultsEl.classList.remove("hidden");
    statusEl.textContent = "";
  } catch (err) {
    console.error(err);
    statusEl.textContent = "Unexpected error loading weather.";
  }
}

document.getElementById("searchBtn").addEventListener("click", () => {
  const query = document.getElementById("query").value.trim();
  const units = document.getElementById("units").value;
  loadWeather({ query, units });
});

document.getElementById("geoBtn").addEventListener("click", () => {
  const units = document.getElementById("units").value;
  if (!navigator.geolocation) {
    statusEl.textContent = "Geolocation is not supported by your browser.";
    return;
  }
  statusEl.textContent = "Getting your location...";
  navigator.geolocation.getCurrentPosition(
    (pos) => {
      const { latitude, longitude } = pos.coords;
      loadWeather({ lat: latitude, lon: longitude, units });
    },
    (err) => {
      statusEl.textContent = "Couldn't get your location: " + err.message;
    },
    { enableHighAccuracy: true, timeout: 10000, maximumAge: 60000 }
  );
});
